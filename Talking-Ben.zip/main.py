import random

dialougue = ["Yes""No""Laughs""ueahhh"]

for i in dialougue range(0,3)

 print(rand)